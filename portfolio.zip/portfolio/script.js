document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize data from LocalStorage or use defaults
    const labs = document.querySelectorAll('.project-card');
    let currentEditId = null;

    // Load saved states
    labs.forEach((card, index) => {
        const id = index + 1;
        card.setAttribute('data-id', id);

        // Prevent default link behavior if no link is set or to allow button click
        card.addEventListener('click', (e) => {
            // If clicking the edit button, don't follow link
            if (e.target.classList.contains('edit-btn')) {
                e.preventDefault();
                openModal(id);
            }
        });

        // Add Edit Button dynamically
        const editBtn = document.createElement('button');
        editBtn.className = 'edit-btn';

        // Check storage
        const savedData = localStorage.getItem(`lab_${id}`);
        if (savedData) {
            const data = JSON.parse(savedData);
            updateCardUI(card, data);
            editBtn.textContent = 'Yangilash';
        } else {
            editBtn.textContent = 'Yuklash';
        }

        card.appendChild(editBtn);
    });

    // 2. Modal Logic
    const modalOverlay = document.getElementById('modalOverlay');
    const linkInput = document.getElementById('labLink');
    const saveBtn = document.getElementById('saveLabBtn');
    const cancelBtn = document.getElementById('cancelLabBtn');

    function openModal(id) {
        currentEditId = id;
        const savedData = localStorage.getItem(`lab_${id}`);
        if (savedData) {
            linkInput.value = JSON.parse(savedData).link;
        } else {
            linkInput.value = '';
        }
        modalOverlay.classList.add('active');
    }

    function closeModal() {
        modalOverlay.classList.remove('active');
        currentEditId = null;
    }

    cancelBtn.addEventListener('click', closeModal);

    // Close on click outside
    modalOverlay.addEventListener('click', (e) => {
        if (e.target === modalOverlay) closeModal();
    });

    // 3. Save Logic
    saveBtn.addEventListener('click', () => {
        if (!currentEditId) return;

        const link = linkInput.value.trim();
        if (!link) {
            alert("Iltimos, linkni kiriting!");
            return;
        }

        const now = new Date();
        const dateString = `${String(now.getDate()).padStart(2, '0')}.${String(now.getMonth() + 1).padStart(2, '0')}.${now.getFullYear()}`;

        const data = {
            link: link,
            date: dateString,
            status: 'completed'
        };

        // Save to storage
        localStorage.setItem(`lab_${currentEditId}`, JSON.stringify(data));

        // Update UI
        const card = document.querySelector(`.project-card[data-id="${currentEditId}"]`);
        updateCardUI(card, data);

        // Update Button text
        const btn = card.querySelector('.edit-btn');
        if (btn) btn.textContent = 'Yangilash';

        closeModal();
    });

    function updateCardUI(card, data) {
        // Update Link
        card.href = data.link;

        // Update Date
        const dateEl = card.querySelector('.project-date');
        if (dateEl) dateEl.textContent = data.date;

        // Update Status
        const statusEl = card.querySelector('.project-status');
        if (statusEl) {
            statusEl.textContent = 'Bajarildi';
            statusEl.className = 'project-status completed'; // Force green class
        }
    }
});
