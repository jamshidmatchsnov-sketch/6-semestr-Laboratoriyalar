let selectedService = null;
let selectedDoctor = null;

// ==========================================
// DATABASE SIMULATION (LocalStorage)
// ==========================================

const DB = {
    // Initial Data (Seed)
    initialDoctors: {
        'Stomatolog': [
            { id: 1, name: 'Yusupov Otabek Ravshanovich', room: '101', experience: '15 yillik tajriba', expYears: 15 },
            { id: 2, name: 'Karimova Nodira Sharofovna', room: '102', experience: '12 yillik tajriba', expYears: 12 },
            { id: 3, name: 'Mahmudov Jasur Alijonovich', room: '103', experience: '10 yillik tajriba', expYears: 10 }
        ],
        'Nevropatolog': [
            { id: 4, name: 'Tursunov Aziz Rahimovich', room: '201', experience: '18 yillik tajriba', expYears: 18 },
            { id: 5, name: 'Abdullayeva Dilnoza Akmalovna', room: '202', experience: '14 yillik tajriba', expYears: 14 },
            { id: 6, name: 'Nazarov Sardor Bakhtiyorovich', room: '203', experience: '11 yillik tajriba', expYears: 11 }
        ],
        'Kardiolog': [
            { id: 7, name: 'Alimov Farhod Murodovich', room: '301', experience: '20 yillik tajriba', expYears: 20 },
            { id: 8, name: 'Rashidova Sevara Botirovna', room: '302', experience: '16 yillik tajriba', expYears: 16 },
            { id: 9, name: 'Ismoilov Bekzod Tulkinovich', room: '303', experience: '13 yillik tajriba', expYears: 13 }
        ],
        'Terapevt': [
            { id: 10, name: 'Nurmatov Anvar Shavkatovich', room: '104', experience: '17 yillik tajriba', expYears: 17 },
            { id: 11, name: 'Rahimova Malika Davronovna', room: '105', experience: '14 yillik tajriba', expYears: 14 },
            { id: 12, name: 'Ergashev Rustam Hamidovich', room: '106', experience: '10 yillik tajriba', expYears: 10 }
        ],
        'Pediatr': [
            { id: 13, name: 'Mirzayeva Gulnora Azimovna', room: '107', experience: '19 yillik tajriba', expYears: 19 },
            { id: 14, name: 'Ahmedov Bobur Olimovich', room: '108', experience: '12 yillik tajriba', expYears: 12 },
            { id: 15, name: 'Sharipova Dildora Karimovna', room: '109', experience: '15 yillik tajriba', expYears: 15 }
        ],
        'Oftalmolog': [
            { id: 16, name: 'Qodirov Jahongir Sobirovich', room: '204', experience: '16 yillik tajriba', expYears: 16 },
            { id: 17, name: 'Azizova Feruza Nuriddinovna', room: '205', experience: '13 yillik tajriba', expYears: 13 },
            { id: 18, name: 'Toshmatov Ulugbek Ibragimovich', room: '206', experience: '11 yillik tajriba', expYears: 11 }
        ],
        'Lor': [
            { id: 19, name: 'Haydarov Sanjar Abdurahmonovich', room: '207', experience: '14 yillik tajriba', expYears: 14 },
            { id: 20, name: 'Safarova Zarina Erkinovna', room: '208', experience: '12 yillik tajriba', expYears: 12 },
            { id: 21, name: 'Karimov Behzod Nosirboyevich', room: '209', experience: '10 yillik tajriba', expYears: 10 }
        ],
        'Dermatolog': [
            { id: 22, name: 'Sultonova Nilufar Ravshanova', room: '304', experience: '15 yillik tajriba', expYears: 15 },
            { id: 23, name: 'Xolmatov Dilshod Azizovich', room: '305', experience: '13 yillik tajriba', expYears: 13 },
            { id: 24, name: 'Hamidova Kamola Shukurovna', room: '306', experience: '11 yillik tajriba', expYears: 11 }
        ],
        'Ginekolog': [
            { id: 25, name: 'Mirzayeva Shoira Rustamovna', room: '307', experience: '18 yillik tajriba', expYears: 18 },
            { id: 26, name: 'Yuldasheva Muhabbat Akmalovna', room: '308', experience: '16 yillik tajriba', expYears: 16 },
            { id: 27, name: 'Ibragimova Munira Davronovna', room: '309', experience: '14 yillik tajriba', expYears: 14 }
        ],
        'Urolog': [
            { id: 28, name: 'Rahmonov Jamshid Ikromovich', room: '210', experience: '17 yillik tajriba', expYears: 17 },
            { id: 29, name: 'Abdullayev Sherzod Nematovich', room: '211', experience: '14 yillik tajriba', expYears: 14 },
            { id: 30, name: 'Nasriddinov Farxod Zafarovich', room: '212', experience: '12 yillik tajriba', expYears: 12 }
        ],
        'Endokrinolog': [
            { id: 31, name: 'Asqarova Malika Botirovna', room: '310', experience: '16 yillik tajriba', expYears: 16 },
            { id: 32, name: 'Saidov Timur Rustamovich', room: '311', experience: '13 yillik tajriba', expYears: 13 },
            { id: 33, name: 'Yunusova Dilfuza Sharipovna', room: '312', experience: '11 yillik tajriba', expYears: 11 }
        ],
        'Travmatolog': [
            { id: 34, name: 'Gafurov Bobir Anvarovich', room: '110', experience: '19 yillik tajriba', expYears: 19 },
            { id: 35, name: 'Normatov Javohir Akmalovich', room: '111', experience: '15 yillik tajriba', expYears: 15 },
            { id: 36, name: 'Salimov Dilshod Rahimovich', room: '112', experience: '12 yillik tajriba', expYears: 12 }
        ],
        // New Service: Treatment Room (Topic 17)
        'Muolaja': [
            { id: 37, name: 'Hamshira Karimova N.', room: 'M-1', experience: '5 yillik tajriba', expYears: 5 },
            { id: 38, name: 'Hamshira Azizova D.', room: 'M-2', experience: '3 yillik tajriba', expYears: 3 },
            { id: 39, name: 'Hamshira Sobirova M.', room: 'M-3', experience: '7 yillik tajriba', expYears: 7 }
        ]
    },

    // Initialize Database
    init: function () {
        if (!localStorage.getItem('doctors')) {
            console.log('Initializing Database...');
            localStorage.setItem('doctors', JSON.stringify(this.initialDoctors));
        }
        if (!localStorage.getItem('appointments')) {
            localStorage.setItem('appointments', JSON.stringify([]));
        }
        if (!localStorage.getItem('queueData')) {
            localStorage.setItem('queueData', JSON.stringify({ date: getTodayDate(), numbers: {} }));
        }
    },

    // Get all doctors
    getDoctors: function () {
        return JSON.parse(localStorage.getItem('doctors'));
    },

    // Save all doctors
    saveDoctors: function (doctors) {
        localStorage.setItem('doctors', JSON.stringify(doctors));
    },

    // Get all appointments
    getAppointments: function () {
        return JSON.parse(localStorage.getItem('appointments'));
    },

    // Add appointment
    addAppointment: function (appointment) {
        const apps = this.getAppointments();
        apps.push(appointment);
        localStorage.setItem('appointments', JSON.stringify(apps));
    },

    // Get Queue Data
    getQueueData: function () {
        let data = JSON.parse(localStorage.getItem('queueData'));
        const today = getTodayDate();
        if (data.date !== today) {
            data = { date: today, numbers: {} };
            this.saveQueueData(data);
        }
        return data;
    },

    // Save Queue Data
    saveQueueData: function (data) {
        localStorage.setItem('queueData', JSON.stringify(data));
    }
};

// Initialize DB on load
DB.init();

// Load data from DB
let doctors = DB.getDoctors();
let appointments = DB.getAppointments();

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

// Get today's date in YYYY-MM-DD format
function getTodayDate() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Display doctors based on selected service
function displayDoctors(serviceName, filterText = '', sortBy = 'default') {
    // Refresh data from DB
    doctors = DB.getDoctors();

    const doctorsGrid = document.getElementById('doctorsGrid');
    const doctorSelectionGroup = document.getElementById('doctorSelectionGroup');

    doctorsGrid.innerHTML = '';
    selectedDoctor = null;

    let serviceDoctors = doctors[serviceName] ? [...doctors[serviceName]] : [];

    // Filter (Topic 17)
    if (filterText) {
        const lowerFilter = filterText.toLowerCase();
        serviceDoctors = serviceDoctors.filter(d =>
            d.name.toLowerCase().includes(lowerFilter)
        );
    }

    // Sort (Topic 18)
    if (sortBy === 'name') {
        serviceDoctors.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === 'experience') {
        serviceDoctors.sort((a, b) => b.expYears - a.expYears);
    }

    if (serviceDoctors && serviceDoctors.length > 0) {
        serviceDoctors.forEach((doctor, index) => {
            const doctorCard = document.createElement('div');
            doctorCard.className = 'doctor-card';
            doctorCard.setAttribute('data-doctor-index', index);

            // Custom icon for Nurses
            const icon = serviceName === 'Muolaja' ? '👩‍⚕️' : '👨‍⚕️';

            doctorCard.innerHTML = `
                <h3>${icon} ${doctor.name}</h3>
                <div class="doctor-info">
                    <p>🚪 Xona: ${doctor.room}</p>
                    <p>⭐ ${doctor.experience}</p>
                </div>
            `;

            doctorCard.addEventListener('click', function () {
                document.querySelectorAll('.doctor-card').forEach(card => {
                    card.classList.remove('selected');
                });
                this.classList.add('selected');
                selectedDoctor = doctor;
                console.log('Tanlangan shifokor:', selectedDoctor);
            });

            doctorsGrid.appendChild(doctorCard);
        });

        doctorSelectionGroup.style.display = 'block';

        // Scroll to doctors section only if not filtering/sorting
        if (!filterText && sortBy === 'default') {
            doctorSelectionGroup.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    } else {
        doctorsGrid.innerHTML = '<p style="text-align: center; width: 100%; color: #666;">Xodim topilmadi</p>';
    }
}

// Service cards selection
document.querySelectorAll('.service-card').forEach((card, index) => {
    // Add animation delay
    card.style.setProperty('--i', index);

    // Add doctor count badge (Topic 22 - Aggregates)
    const serviceName = card.dataset.service;
    const count = doctors[serviceName] ? doctors[serviceName].length : 0;

    // Remove existing badge if any
    const existingBadge = card.querySelector('.doc-count-badge');
    if (existingBadge) existingBadge.remove();

    const badge = document.createElement('span');
    badge.className = 'doc-count-badge';
    badge.textContent = count;
    card.appendChild(badge);

    card.addEventListener('click', function (e) {
        e.preventDefault();

        // Remove selected class from all service cards
        document.querySelectorAll('.service-card').forEach(c => {
            c.classList.remove('selected');
        });

        // Add selected class to clicked card
        this.classList.add('selected');
        selectedService = this.dataset.service;

        console.log('Tanlangan hizmat:', selectedService);

        // Reset search and sort
        document.getElementById('doctorSearch').value = '';
        document.getElementById('doctorSort').value = 'default';

        // Display doctors for selected service
        displayDoctors(selectedService);
    });
});

// Search and Sort Event Listeners
document.getElementById('doctorSearch').addEventListener('input', (e) => {
    if (selectedService) {
        displayDoctors(selectedService, e.target.value, document.getElementById('doctorSort').value);
    }
});

document.getElementById('doctorSort').addEventListener('change', (e) => {
    if (selectedService) {
        displayDoctors(selectedService, document.getElementById('doctorSearch').value, e.target.value);
    }
});

// Update Statistics (Topic 22)
function updateStats() {
    // Refresh data
    doctors = DB.getDoctors();

    let totalDocs = 0;
    let servicesCount = Object.keys(doctors).length;

    Object.values(doctors).forEach(list => {
        totalDocs += list.length;
    });

    // Simulate today's patients (random for demo)
    const todayPatients = Math.floor(Math.random() * 50) + 10;

    document.getElementById('totalDoctors').textContent = totalDocs;
    document.getElementById('activeServices').textContent = servicesCount;
    document.getElementById('todayPatients').textContent = todayPatients;

    // Update badges
    document.querySelectorAll('.service-card').forEach(card => {
        const serviceName = card.dataset.service;
        const count = doctors[serviceName] ? doctors[serviceName].length : 0;
        const badge = card.querySelector('.doc-count-badge');
        if (badge) badge.textContent = count;
    });
}

// Live Clock (Topic 25)
function updateClock() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('uz-UZ');
    document.getElementById('liveClock').textContent = timeString;
}

setInterval(updateClock, 1000);
updateClock();
updateStats();

// ==========================================
// UZBEKISTAN CUSTOMIZATION (Address & Phone)
// ==========================================

const uzbekistanData = {
    "Toshkent shahri": ["Bektemir", "Chilonzor", "Hamza (Yashnobod)", "Mirobod", "Mirzo Ulug'bek", "Sergeli", "Shayxontohur", "Olmazor", "Uchtepa", "Yakkasaroy", "Yunusobod", "Yangihayot"],
    "Toshkent viloyati": ["Angren sh.", "Bekobod sh.", "Chirchiq sh.", "Olmaliq sh.", "Ohangaron sh.", "Yangiyo'l sh.", "Nurafshon sh.", "Bo'ka", "Chinoz", "Parkent", "Piskent", "Zangiota", "Qibray", "Yuqori Chirchiq", "O'rta Chirchiq", "Quyi Chirchiq"],
    "Andijon viloyati": ["Andijon sh.", "Xonobod sh.", "Asaka", "Baliqchi", "Bo'z", "Buloqboshi", "Izboskan", "Jalaquduq", "Marhamat", "Oltinko'l", "Paxtaobod", "Qo'rg'ontepa", "Shahrixon", "Ulug'nor", "Xo'jaobod"],
    "Buxoro viloyati": ["Buxoro sh.", "Kogon sh.", "Olot", "Buxoro", "G'ijduvon", "Jondor", "Kogon", "Qorako'l", "Qorovulbozor", "Peshku", "Romitan", "Shofirkon", "Vobkent"],
    "Farg'ona viloyati": ["Farg'ona sh.", "Marg'ilon sh.", "Qo'qon sh.", "Quvasoy sh.", "Beshariq", "Bog'dod", "Buvayda", "Dang'ara", "Farg'ona", "Furqat", "Qo'shtepa", "Quva", "Rishton", "So'x", "Toshloq", "Uchko'prik", "O'zbekiston", "Yozyovon"],
    "Jizzax viloyati": ["Jizzax sh.", "Arnasoy", "Baxmal", "Do'stlik", "Forish", "G'allaorol", "Sharof Rashidov", "Mirzacho'l", "Paxtakor", "Yangiobod", "Zomin", "Zafarobod", "Zarbdor"],
    "Xorazm viloyati": ["Urganch sh.", "Xiva sh.", "Bog'ot", "Gurlan", "Xonqa", "Hazorasp", "Xiva", "Qo'shko'pir", "Shovot", "Urganch", "Yangibozor", "Yangiarik"],
    "Namangan viloyati": ["Namangan sh.", "Chortoq", "Chust", "Kosonsoy", "Mingbuloq", "Namangan", "Norin", "Pop", "To'raqo'rg'on", "Uchqo'rg'on", "Uychi", "Yangiqo'rg'on"],
    "Navoiy viloyati": ["Navoiy sh.", "Zarafshon sh.", "Karmana", "Konimex", "Qiziltepa", "Navbahor", "Nurota", "Tomdi", "Uchquduq", "Xatirchi"],
    "Qashqadaryo viloyati": ["Qarshi sh.", "Shahrisabz sh.", "Chiroqchi", "Dehqonobod", "G'uzor", "Kasbi", "Kitob", "Koson", "Mirishkor", "Muborak", "Nishon", "Qamashi", "Qarshi", "Yakkabog'"],
    "Qoraqalpog'iston Respublikasi": ["Nukus sh.", "Amudaryo", "Beruniy", "Chimboy", "Ellikqal'a", "Kegeyli", "Mo'ynoq", "Nukus", "Qanliko'l", "Qo'ng'irot", "Qorao'zak", "Shumanay", "Taxtako'pir", "To'rtko'l", "Xo'jayli"],
    "Samarqand viloyati": ["Samarqand sh.", "Kattaqo'rg'on sh.", "Bulung'ur", "Ishtixon", "Jomboy", "Kattaqo'rg'on", "Qo'shrabot", "Narpay", "Nurobod", "Oqdaryo", "Paxtachi", "Payariq", "Pastdarg'om", "Samarqand", "Toyloq", "Urgut"],
    "Sirdaryo viloyati": ["Guliston sh.", "Yangiyer sh.", "Shirin sh.", "Boyovut", "Guliston", "Mirzaobod", "Oqoltin", "Sardoba", "Sayxunobod", "Sirdaryo", "Xovos"],
    "Surxondaryo viloyati": ["Termiz sh.", "Angor", "Bandixon", "Boysun", "Denov", "Jarqo'rg'on", "Qiziriq", "Qumqo'rg'on", "Muzrabot", "Oltinsoy", "Sariosiyo", "Sherobod", "Sho'rchi", "Termiz", "Uzun"]
};

function populateRegions() {
    const regionSelect = document.getElementById('regionSelect');
    if (!regionSelect) return;

    // Clear existing options except the first one
    while (regionSelect.options.length > 1) {
        regionSelect.remove(1);
    }

    Object.keys(uzbekistanData).forEach(region => {
        const option = document.createElement('option');
        option.value = region;
        option.textContent = region;
        regionSelect.appendChild(option);
    });

    // Add event listener for region change
    regionSelect.addEventListener('change', function () {
        populateDistricts(this.value);
    });
}

function populateDistricts(region) {
    const districtSelect = document.getElementById('districtSelect');
    if (!districtSelect) return;

    // Reset district select
    districtSelect.innerHTML = '<option value="">Tuman/Shaharni tanlang</option>';
    districtSelect.disabled = true;

    if (region && uzbekistanData[region]) {
        uzbekistanData[region].forEach(district => {
            const option = document.createElement('option');
            option.value = district;
            option.textContent = district;
            districtSelect.appendChild(option);
        });
        districtSelect.disabled = false;
    }
}

// Phone Number Formatting
function initPhoneInput() {
    const phoneInput = document.getElementById('phone');
    if (!phoneInput) return;

    phoneInput.addEventListener('input', function (e) {
        let value = e.target.value;

        // Ensure +998 prefix exists
        if (!value.startsWith('+998 ')) {
            value = '+998 ' + value.replace(/^\+998\s?/, '');
        }

        // Allow only numbers and spaces after prefix
        const prefix = '+998 ';
        let numbers = value.substring(prefix.length).replace(/[^\d]/g, '');

        // Limit to 9 digits
        if (numbers.length > 9) {
            numbers = numbers.substring(0, 9);
        }

        // Format: 90 123 45 67
        let formatted = prefix;
        if (numbers.length > 0) formatted += numbers.substring(0, 2);
        if (numbers.length > 2) formatted += ' ' + numbers.substring(2, 5);
        if (numbers.length > 5) formatted += ' ' + numbers.substring(5, 7);
        if (numbers.length > 7) formatted += ' ' + numbers.substring(7, 9);

        e.target.value = formatted;
    });

    // Prevent deleting prefix
    phoneInput.addEventListener('keydown', function (e) {
        if (e.target.selectionStart < 5 && (e.key === 'Backspace' || e.key === 'Delete')) {
            e.preventDefault();
        }
    });
}

// Form submission
document.getElementById('appointmentForm').addEventListener('submit', function (e) {
    e.preventDefault();

    if (!selectedService) {
        alert('❗ Iltimos, hizmat turini tanlang!');
        return;
    }

    if (!selectedDoctor) {
        alert('❗ Iltimos, shifokorni tanlang!');
        return;
    }

    const fullName = document.getElementById('fullName').value.trim();

    // Get Address Parts
    const region = document.getElementById('regionSelect').value;
    const district = document.getElementById('districtSelect').value;
    const street = document.getElementById('streetInput').value.trim();

    const address = `${region}, ${district}, ${street}`;

    const phone = document.getElementById('phone').value.trim();

    // Validate inputs
    if (!fullName || !region || !district || !street || !phone) {
        alert('❗ Iltimos, barcha maydonlarni to\'ldiring!');
        return;
    }

    // Load current queue numbers from DB
    let queueData = DB.getQueueData();
    let queueNumbers = queueData.numbers;

    // Generate queue number for specific doctor
    const doctorKey = selectedService + '_' + selectedDoctor.room;
    if (!queueNumbers[doctorKey]) {
        queueNumbers[doctorKey] = 0;
    }
    queueNumbers[doctorKey]++;

    const queueNumber = selectedService.charAt(0).toUpperCase() + '-' +
        String(queueNumbers[doctorKey]).padStart(3, '0');

    // Save updated queue numbers to DB
    queueData.numbers = queueNumbers;
    DB.saveQueueData(queueData);

    // Get current date and time
    const now = new Date();
    const options = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    const dateTime = now.toLocaleDateString('uz-UZ', options);

    // Save appointment to DB (Topic 20 - Join)
    const newAppointment = {
        patientName: fullName,
        doctorName: selectedDoctor.name,
        service: selectedService,
        time: now.toLocaleTimeString('uz-UZ'),
        queueNumber: queueNumber
    };
    DB.addAppointment(newAppointment);
    appointments = DB.getAppointments(); // Refresh local var

    // Fill ticket information
    document.getElementById('ticketNumber').textContent = queueNumber;
    document.getElementById('ticketName').textContent = fullName;
    document.getElementById('ticketAddress').textContent = address;
    document.getElementById('ticketPhone').textContent = phone;
    document.getElementById('ticketService').textContent = selectedService;
    document.getElementById('ticketDoctor').textContent = selectedDoctor.name;
    document.getElementById('ticketRoom').textContent = selectedDoctor.room;
    document.getElementById('ticketDateTime').textContent = dateTime;

    // Show ticket, hide form
    document.getElementById('formSection').style.display = 'none';
    document.getElementById('ticketSection').classList.add('show');

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    console.log('Navbat qog\'ozi yaratildi:', queueNumber);
});

// Reset form function
function resetForm() {
    // Reset form fields
    document.getElementById('appointmentForm').reset();

    // Remove selected class from all cards
    document.querySelectorAll('.service-card').forEach(c => {
        c.classList.remove('selected');
    });

    document.querySelectorAll('.doctor-card').forEach(c => {
        c.classList.remove('selected');
    });

    // Clear selected service and doctor
    selectedService = null;
    selectedDoctor = null;

    // Hide doctor selection
    document.getElementById('doctorSelectionGroup').style.display = 'none';

    // Show form, hide ticket
    document.getElementById('formSection').style.display = 'block';
    document.getElementById('ticketSection').classList.remove('show');

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    console.log('Forma qayta yuklandi');
}

// ==========================================
// ADMIN PANEL LOGIC (Topics 16-30)
// ==========================================

// Admin Login (Topic 30 - Security)
const adminToggleBtn = document.getElementById('adminToggleBtn');
const adminLoginModal = document.getElementById('adminLoginModal');
const adminDashboard = document.getElementById('adminDashboard');
const closeModal = document.querySelector('.close-modal');

adminToggleBtn.addEventListener('click', () => {
    adminLoginModal.style.display = 'flex';
});

closeModal.addEventListener('click', () => {
    adminLoginModal.style.display = 'none';
});

function checkAdminLogin() {
    const password = document.getElementById('adminPassword').value;
    if (password === '1234') {
        adminLoginModal.style.display = 'none';
        adminDashboard.style.display = 'block';
        document.body.style.overflow = 'hidden'; // Disable background scroll
        loadAdminData();
    } else {
        alert('❌ Parol noto\'g\'ri!');
        document.getElementById('adminPassword').classList.add('shake'); // Animation
        setTimeout(() => document.getElementById('adminPassword').classList.remove('shake'), 500);
    }
}

function logoutAdmin() {
    adminDashboard.style.display = 'none';
    document.body.style.overflow = 'auto';
    document.getElementById('adminPassword').value = '';
}

// Tab Switching
function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));

    document.getElementById(tabId).classList.add('active');
    event.target.classList.add('active');
}

// Load Admin Data
function loadAdminData() {
    // Refresh data from DB
    doctors = DB.getDoctors();
    appointments = DB.getAppointments();

    renderDoctorsTable();
    renderAppointmentsTable();
    renderAllUsersTable();
    renderAnalyticsTab(); // New Analytics
    populateServiceSelect();
}

// 1. Doctors Management (Topic 16 - DDL/Insert, Topic 29 - Edit)
function renderDoctorsTable() {
    const tbody = document.querySelector('#doctorsTable tbody');
    tbody.innerHTML = '';

    Object.keys(doctors).forEach(service => {
        doctors[service].forEach(doc => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${doc.name}</td>
                <td>${service}</td>
                <td>${doc.room}</td>
                <td>${doc.experience}</td>
                <td>
                    <button class="delete-btn" onclick="deleteDoctor('${service}', ${doc.id})">🗑️</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    });
}

function populateServiceSelect() {
    const select = document.getElementById('newDocService');
    select.innerHTML = '<option value="">Bo\'limni tanlang</option>';
    Object.keys(doctors).forEach(service => {
        const option = document.createElement('option');
        option.value = service;
        option.textContent = service;
        select.appendChild(option);
    });
}

function addNewDoctor(e) {
    e.preventDefault();
    const name = document.getElementById('newDocName').value;
    const service = document.getElementById('newDocService').value;
    const room = document.getElementById('newDocRoom').value;
    const exp = document.getElementById('newDocExp').value;

    const newDoc = {
        id: Date.now(), // Simple ID generation
        name: name,
        room: room,
        experience: exp + ' yillik tajriba',
        expYears: parseInt(exp)
    };

    // Update DB
    doctors[service].push(newDoc);
    DB.saveDoctors(doctors);

    alert('✅ Xodim muvaffaqiyatli qo\'shildi!');
    e.target.reset();
    renderDoctorsTable();
    updateStats(); // Update stats on main page
}

function deleteDoctor(service, id) {
    if (confirm('Rostdan ham o\'chirmoqchimisiz?')) {
        doctors[service] = doctors[service].filter(d => d.id !== id);
        DB.saveDoctors(doctors);
        renderDoctorsTable();
        updateStats();
    }
}

// 2. Appointments Log (Topic 20 - Join)
function renderAppointmentsTable() {
    const tbody = document.querySelector('#appointmentsTable tbody');
    tbody.innerHTML = '';

    if (appointments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center">Hozircha qabullar yo\'q</td></tr>';
        return;
    }

    appointments.forEach(app => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${app.patientName}</td>
            <td>${app.doctorName}</td>
            <td>${app.service}</td>
            <td>${app.time}</td>
            <td><strong>${app.queueNumber}</strong></td>
        `;
        tbody.appendChild(tr);
    });
}

// 3. All Users View (Topic 21 - Union)
function renderAllUsersTable() {
    const tbody = document.querySelector('#allUsersTable tbody');
    tbody.innerHTML = '';

    // Union: Doctors + Patients
    let allUsers = [];

    // Add Doctors
    Object.values(doctors).forEach(list => {
        list.forEach(doc => {
            allUsers.push({ name: doc.name, role: 'Xodim 👨‍⚕️', info: doc.experience });
        });
    });

    // Add Patients (from appointments)
    appointments.forEach(app => {
        allUsers.push({ name: app.patientName, role: 'Bemor 👤', info: 'Navbat: ' + app.queueNumber });
    });

    allUsers.forEach(user => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${user.name}</td>
            <td>${user.role}</td>
            <td>${user.info}</td>
        `;
        tbody.appendChild(tr);
    });
}

// 4. Analytics & Reports (Topic 18 - Manager View)
function renderAnalyticsTab() {
    // Calculate Stats
    const totalPatients = appointments.length;
    const revenue = totalPatients * 50000; // Simulated price: 50,000 UZS per visit

    // Find most popular service
    const serviceCounts = {};
    appointments.forEach(app => {
        serviceCounts[app.service] = (serviceCounts[app.service] || 0) + 1;
    });

    let topService = '-';
    let maxCount = 0;
    Object.entries(serviceCounts).forEach(([service, count]) => {
        if (count > maxCount) {
            maxCount = count;
            topService = service;
        }
    });

    // Update Summary Cards
    document.getElementById('reportTotalPatients').textContent = totalPatients;
    document.getElementById('reportTopService').textContent = topService;
    document.getElementById('reportRevenue').textContent = revenue.toLocaleString() + ' so\'m';

    // Doctor Ratings Table
    const doctorCounts = {};
    appointments.forEach(app => {
        doctorCounts[app.doctorName] = (doctorCounts[app.doctorName] || 0) + 1;
    });

    // Convert to array and sort
    const ratings = Object.entries(doctorCounts)
        .map(([name, count]) => ({ name, count }))
        .sort((a, b) => b.count - a.count);

    const tbody = document.querySelector('#analyticsTable tbody');
    tbody.innerHTML = '';

    if (ratings.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center">Ma\'lumot yetarli emas</td></tr>';
        return;
    }

    ratings.forEach((r, index) => {
        let status = '🟢 Normal';
        if (r.count > 5) status = '🔴 Yuqori Yuklama';
        else if (r.count > 2) status = '🟡 O\'rtacha';

        // Find service for this doctor
        let docService = 'Noma\'lum';
        Object.keys(doctors).forEach(s => {
            const found = doctors[s].find(d => d.name === r.name);
            if (found) docService = s;
        });

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>#${index + 1}</td>
            <td>${r.name}</td>
            <td>${docService}</td>
            <td>${r.count}</td>
            <td>${status}</td>
        `;
        tbody.appendChild(tr);
    });
}

// Initialize on page load
window.addEventListener('load', function () {
    console.log('✅ Navbat tizimi ishga tushdi (LocalStorage)');
    console.log('📅 Bugungi sana:', getTodayDate());

    // Initialize Uzbekistan Customization
    populateRegions();
    initPhoneInput();
});
// Valyuta kurslarini olish funksiyasi (AJAX - Fetch API)
async function fetchCurrencyRates() {
    try {
        // Markaziy bank yoki ochiq API-dan ma'lumot olish
        const response = await fetch('https://cbu.uz/uz/arkhiv-kursov-valyut/json/');
        const data = await response.json();

        // Ma'lumotlar ichidan kerakli valyutalarni ajratib olish
        const usd = data.find(item => item.Ccy === 'USD');
        const eur = data.find(item => item.Ccy === 'EUR');
        const rub = data.find(item => item.Ccy === 'RUB');

        // HTML-ga natijalarni chiqarish
        document.getElementById('usdRate').innerText = usd.Rate + ' so\'m';
        document.getElementById('eurRate').innerText = eur.Rate + ' so\'m';
        document.getElementById('rubRate').innerText = rub.Rate + ' so\'m';

    } catch (error) {
        console.error("Valyuta kursini olishda xatolik:", error);
        document.getElementById('currencyRates').innerText = "Kurslarni yuklab bo'lmadi";
    }
}

// Sahifa yuklanganda funksiyani ishga tushirish
fetchCurrencyRates();