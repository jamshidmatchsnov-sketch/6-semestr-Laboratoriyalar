const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '.'))); // Serve static files

// Database Setup
const db = new sqlite3.Database('./clinic.db', (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        initializeDatabase();
    }
});

function initializeDatabase() {
    db.serialize(() => {
        // Create Doctors Table
        db.run(`CREATE TABLE IF NOT EXISTS doctors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            service TEXT,
            room TEXT,
            experience TEXT,
            expYears INTEGER
        )`);

        // Create Appointments Table
        db.run(`CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patientName TEXT,
            doctorName TEXT,
            service TEXT,
            time TEXT,
            queueNumber TEXT
        )`);

        // Seed Data (only if empty)
        db.get("SELECT count(*) as count FROM doctors", (err, row) => {
            if (row.count === 0) {
                console.log("Seeding initial data...");
                const initialDoctors = [
                    // Stomatolog
                    { name: 'Yusupov Otabek Ravshanovich', service: 'Stomatolog', room: '101', experience: '15 yillik tajriba', expYears: 15 },
                    { name: 'Karimova Nodira Sharofovna', service: 'Stomatolog', room: '102', experience: '12 yillik tajriba', expYears: 12 },
                    { name: 'Mahmudov Jasur Alijonovich', service: 'Stomatolog', room: '103', experience: '10 yillik tajriba', expYears: 10 },
                    // Nevropatolog
                    { name: 'Tursunov Aziz Rahimovich', service: 'Nevropatolog', room: '201', experience: '18 yillik tajriba', expYears: 18 },
                    { name: 'Abdullayeva Dilnoza Akmalovna', service: 'Nevropatolog', room: '202', experience: '14 yillik tajriba', expYears: 14 },
                    // Kardiolog
                    { name: 'Alimov Farhod Murodovich', service: 'Kardiolog', room: '301', experience: '20 yillik tajriba', expYears: 20 },
                    // Terapevt
                    { name: 'Nurmatov Anvar Shavkatovich', service: 'Terapevt', room: '104', experience: '17 yillik tajriba', expYears: 17 },
                    // Pediatr
                    { name: 'Mirzayeva Gulnora Azimovna', service: 'Pediatr', room: '107', experience: '19 yillik tajriba', expYears: 19 }
                ];

                const stmt = db.prepare("INSERT INTO doctors (name, service, room, experience, expYears) VALUES (?, ?, ?, ?, ?)");
                initialDoctors.forEach(doc => {
                    stmt.run(doc.name, doc.service, doc.room, doc.experience, doc.expYears);
                });
                stmt.finalize();
            }
        });
    });
}

// API Endpoints

// Get all doctors
app.get('/api/doctors', (req, res) => {
    db.all("SELECT * FROM doctors", [], (err, rows) => {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json({
            "message": "success",
            "data": rows
        });
    });
});

// Add a new doctor
app.post('/api/doctors', (req, res) => {
    const { name, service, room, experience, expYears } = req.body;
    const sql = "INSERT INTO doctors (name, service, room, experience, expYears) VALUES (?, ?, ?, ?, ?)";
    const params = [name, service, room, experience, expYears];

    db.run(sql, params, function (err) {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json({
            "message": "success",
            "data": { id: this.lastID, ...req.body }
        });
    });
});

// Delete a doctor
app.delete('/api/doctors/:id', (req, res) => {
    const sql = "DELETE FROM doctors WHERE id = ?";
    db.run(sql, req.params.id, function (err) {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json({ "message": "deleted", changes: this.changes });
    });
});

// Get all appointments
app.get('/api/appointments', (req, res) => {
    db.all("SELECT * FROM appointments", [], (err, rows) => {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json({
            "message": "success",
            "data": rows
        });
    });
});

// Add an appointment
app.post('/api/appointments', (req, res) => {
    const { patientName, doctorName, service, time, queueNumber } = req.body;
    const sql = "INSERT INTO appointments (patientName, doctorName, service, time, queueNumber) VALUES (?, ?, ?, ?, ?)";
    const params = [patientName, doctorName, service, time, queueNumber];

    db.run(sql, params, function (err) {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json({
            "message": "success",
            "data": { id: this.lastID, ...req.body }
        });
    });
});

// Start Server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
