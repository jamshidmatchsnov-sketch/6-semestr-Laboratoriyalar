<?php
// Sessiyani boshlaymiz
session_start();

if (isset($_POST['submit'])) {
    // Formadan kelgan ma'lumotlarni sessiya o'zgaruvchilariga yuklaymiz
    $_SESSION['ism'] = $_POST['ism'];
    $_SESSION['familiya'] = $_POST['familiya'];
    $_SESSION['email'] = $_POST['email'];
    $_SESSION['telefon'] = $_POST['telefon'];
    $_SESSION['login'] = $_POST['login'];

    echo "<h3>Ma'lumotlar sessiyaga muvaffaqiyatli yozildi!</h3>";
}

// Sessiyadagi ma'lumotlarni ekranga chiqaramiz
if (isset($_SESSION['login'])) {
    echo "<h4>Sessiyadagi foydalanuvchi ma'lumotlari:</h4>";
    echo "<b>Ism:</b> " . $_SESSION['ism'] . "<br>";
    echo "<b>Familiya:</b> " . $_SESSION['familiya'] . "<br>";
    echo "<b>Email:</b> " . $_SESSION['email'] . "<br>";
    echo "<b>Telefon:</b> " . $_SESSION['telefon'] . "<br>";
    echo "<b>Login:</b> " . $_SESSION['login'] . "<br>";
} else {
    echo "Hech qanday ma'lumot topilmadi.";
}

echo '<br><a href="form.php">Orqaga qaytish</a>';
?>