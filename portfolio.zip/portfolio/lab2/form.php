<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Sessiya bilan ishlash</title>
</head>
<body>
    <h2>Ro'yxatdan o'tish formasi</h2>
    <form action="process.php" method="post">
        Ism: <input type="text" name="ism" required><br><br>
        Familiya: <input type="text" name="familiya" required><br><br>
        Email: <input type="email" name="email" required><br><br>
        Telefon: <input type="tel" name="telefon" placeholder="+998901234567" required><br><br>
        Login: <input type="text" name="login" required><br><br>
        <button type="submit" name="submit">Ma'lumotlarni saqlash</button>
    </form>
</body>
</html>